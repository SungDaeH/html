$(".navi>li").mouseover(function(){
    $(this).find(".sub").stop().slideDown();
})
$(".navi>li").mouseout(function(){
    $(this).find(".sub").stop().slideUp();
})

setInterval(function(){
    $(".slidelist").delay(2000);
    $(".slidelist").animate({marginLeft : -200 + "vh"})
    $(".slidelist").delay(2000);
    $(".slidelist").animate({marginLeft : -400 + "vh"})
    $(".slidelist").delay(2000);
    $(".slidelist").animate({marginLeft : 0 + "vh"})
})